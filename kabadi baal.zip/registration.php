<!DOCTYPE html>
<html>
<head>
	<title>Shamsu</title>
	<style type="text/css">
		input{
			min-width: 50%;
			height: 25px;
			border-radius: 5%;
		}
	</style>
</head>
<body>
<h1 align="center">LOGIN</h1>
<div align="center">
	<form method="post" action="accesscontrol.php">
		<input type="text" name="username" placeholder="Username" required><br><br><br>
		<input type="email" name="email" placeholder="Email" required><br><br><br>
		<input type="password" name="password" placeholder="Password" required><br><br><br><br>
		<input type="submit" name="regi" value="Registration">
	</form>
</div>
</body>
</html>