<?php require_once 'navbar.php'; 

 if($_SESSION['log'] == "in" && $_SESSION['userid'] == '3'){
?>
  <br/><br/>
   <div class="single-blog-page">
              <!-- recent start -->
              <div class="left-blog">
               
                <div class="recent-post">
                  <!-- start single post -->
                  <div class="recent-single-post">
                    
                    
                    
                    <div class="pst-content">
                     
				 
					  <div id="userlist" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>User List</h2>
          </div>
        </div>
      </div>
	            <?php 
     if (isset($_SESSION['udelete'])) {
       echo $_SESSION['udelete'];
     }
     

      ?>  
	  <!-- Search Area -->
	  <div class="md-form mt-0">
      <input class="form-control" type="text" placeholder="Search" aria-label="Search">
       </div>
	   <!-- Search End -->

	   <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">UserName</th>
      <th scope="col">Email</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    require_once 'datalink.php';
    $usersql = mysqli_query($conn,"SELECT * FROM user");

    while ($row = mysqli_fetch_assoc($usersql)) {
      
    
     ?>
    <tr>
      <th><?php echo $row['id']; ?></th>
      <td><?php echo $row['username']; ?></td>
      <td><?php echo $row['email']; ?></td>
      <td> <a href="userdelete.php/?id=<?php echo $row['id']; ?>">Delete</a></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
     
    </div>
  </div>

					 
					 
					 
					 
					 
                    </div>
                  </div>
                  <!-- End single post -->
                  <!-- start single post -->
                  <div class="recent-single-post">
                    
                    <div class="pst-content">
                    
                     
					 
					  <div id="postlist" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Post</h2>
          </div>
        </div>
      </div>
	  
	  <!-- Search Area -->
	  <div class="md-form mt-0">
      <input class="form-control" type="text" placeholder="Search" aria-label="Search">
       </div>
	   <!-- Search End -->
	   
	     <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th>USER</th>
      <th scope="col">TML</th>
      <th scope="col">Draft</th>
      <th scope="col">Describe</th>
    <th scope="col">Tags / Cetagories</th>
    <th scope="col">Publish</th>
    <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php

    require_once 'datalink.php';

    $postsql = mysqli_query($conn, "SELECT * FROM kabadi LEFT JOIN user ON user.id = kabadi.userid");

    while($posts = mysqli_fetch_assoc($postsql))
{
     ?>
    <tr>
      <th><?php echo $posts['id']; ?></th>
      <th><?php echo $posts['username']; ?></th>

      <td><?php echo $posts['name']; ?></td>
      <td><?php echo $posts['email']; ?></td>
      <td><?php echo $posts['subject']; ?></td>
    <td><?php echo $posts['message']; ?></td>
    <td><?php echo $posts['createdate']; ?></td>
     <td><a href="userpaneledit.php/?id=<?php echo $posts['id']; ?>">Edit</a> <a href="userpaneldelete.php/?id=<?php echo $posts['id']; ?>">Delete</a></td>
    </tr>
    <?php } ?>
  </tbody>
</table>
     
    </div>
  </div>
                  
				  </div>
				  </div>
				  
                  <!-- End single post -->
                  <!-- start single post -->
                  <div class="recent-single-post">
                   
                    <div class="pst-content">
                     
					  <div class="row">
					  
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="faq-details">
            <div class="panel-group" id="comment">
              <!-- Panel Default -->
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="check-title">
											<a data-toggle="collapse" class="active" data-parent="#accordion" href="#check1">
                                                <span class="acc-icons"></span>Comments
											</a>
										</h4>
                </div>
                <div id="check1" class="panel-collapse collapse in">
                  <div class="panel-body">
                    <p>
                      Redug Lefes dolor sit amet, consectetur adipisicing elit. Aspernatur, tempore, commodi quas mollitia dolore magnam quidem repellat, culpa voluptates laboriosam maiores alias accusamus recusandae vero
                    </p>
                  </div>
                </div>
              </div></div></div></div></div>
					 
					 
					 
					 
                    </div>
                  </div>
                  <!-- End single post -->
                  <!-- start single post -->
                  <div class="recent-single-post">
                  
                    <div class="pst-content">
                    
					
							  <div id="tags" class="about-area area-padding">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Tags / Cetagories</h2>
          </div>
        </div>
      </div>
	  
	  <!-- Search Area -->
	  <div class="md-form mt-0">
      <input class="form-control" type="text" placeholder="Add New Tags" aria-label="Search">
       </div>
	   <!-- Search End -->
	   
	   <table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Tag Name</th>
      <th scope="col">Describe</th>
	  <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>English</td>
      <td>We Dont Talk Anymore</td>
	   <td><a href="df">Edit</a> <a href="df">Delete</a></td>
    </tr>
    
  </tbody>
</table>
     
    </div>
  </div>
					
					
					
					
					
					
					
                    </div>
                  </div>
                  <!-- End single post -->
                </div>
              </div>
              <!-- recent end -->
            </div>
  
  
  
  <!-- header end -->
  
  
 
  <!-- Start Slider Area -->


  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

<?php } ?>
</body>

</html>
